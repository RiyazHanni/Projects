<?php
require_once "connect.php";

$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";

if ($_SERVER['REQUEST_METHOD'] == "POST"){

    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Username cannot be blank";
    }
    else{
        $sql = "SELECT id FROM users WHERE username = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if($stmt)
        {
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            // Set the value of param username
            $param_username = trim($_POST['username']);

            // Try to execute this statement
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                if(mysqli_stmt_num_rows($stmt) == 1)
                {
                    $username_err = "This username is already taken"; 
                }
                else{
                    $username = trim($_POST['username']);
                }
            }
            else{
                echo "Something went wrong";
            }
        }
    }

    mysqli_stmt_close($stmt);


// Check for password
if(empty(trim($_POST['password']))){
    $password_err = "Password cannot be blank";
}
elseif(strlen(trim($_POST['password'])) < 5){
    $password_err = "Password cannot be less than 5 characters";
}
else{
    $password = trim($_POST['password']);
}

// Check for confirm password field
if(trim($_POST['password']) !=  trim($_POST['confirm_password'])){
    $password_err = "Passwords should match";
}


// If there were no errors, go ahead and insert into the database
if(empty($username_err) && empty($password_err) && empty($confirm_password_err))
{
    $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt)
    {
        mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);

        // Set these parameters
        $param_username = $username;
        $param_password = password_hash($password, PASSWORD_DEFAULT);

        // Try to execute the query
        if (mysqli_stmt_execute($stmt))
        {
            header("location: login.php");
        }
        else{
            echo "Something went wrong... cannot redirect!";
        }
    }
    mysqli_stmt_close($stmt);
}
mysqli_close($conn);
}

?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form - Sign Up </title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <div class="a">
        <div class="container">
            <div class="Heading">
                <div class="subhead">
                    <h4>REGISTRATION FORM</h4><br>
                </div>
            </div>

            <form action="index.php" method="POST">
                <div class="userdetails">

                    <div class="col">
                        <label for="fname" class="c">Full name:</label>
                        <input type="text" class="d" name="Fullname" id="fname" placeholder="  Enter your name"
                            required>
                    </div>

                    <div class="col">
                        <label for="lname" class="c">Username:</label>
                        <input type="text" class="d" name="Username" id="lname" placeholder="  Enter ypur username"
                            required>
                    </div>



                    <div class="col">
                        <label for="email" class="c">Email:</label>
                        <input type="text" class="d" name="Email" id="email" placeholder="  Enter your e-mail" required>
                    </div>
                    <div class="col">
                        <label for="number" class="c">Phone number:</label>
                        <input type="text" class="d" name="Phonenumber" id="number" placeholder="  Enter your number" required>
                    </div>
                    <div class="col">
                        <label for="password" class="c">Password:</label>
                        <input type="text" class="d" name="Password" id="password" placeholder="  Enter your password" required>
                    </div>
                    <div class="col">
                        <label for="Conformpassword" class="c">Confirm Password:</label>
                        <input type="text" class="d" name="Confirmpassword" id="Confirmpassword"
                            placeholder="  Confirm your password" required>
                    </div>

                    <div class="sextype">
                        <label for="lname" class="e">Gender:</label>
                        <input class="sex" name="Gender " value="M" type="radio" id="gm" >
                        <label class="f" for="gm"> Male</label>
                        <input class="sex" name="Gender" value="F" type="radio" id="gf" >
                        <label class="f" for="gf"> Female</label>
                        <input class="sex" name="Gender" value="O" type="radio" id="go" >
                        <label class="f" for="go"> other</label>


                    </div>


                    <div class="dob">
                        <label for="start" class="db">Date of birth : </label>
                        <input class="bday" type="date" name="Dateofbirth" id="start" value="2021-31-08"
                            min="2000-01-01" max="2021-8-31" required>
                    </div>



                    <div class="button">
                        <input type="submit" name="submit" value="Register" required>
                    </div>

                </div>
            </form>

        </div>
    </div>

</body>

</html>