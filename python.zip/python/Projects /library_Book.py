
class library:
    
    def __init__ (self,books): 
        print(" welcome to the library student \n ")
        print("What can i help u with ?: \n")
        self.book=books
    
    def availablebooks(self):
        for i in self.book:
            print("  *  "+ i)
    
    def issuebook(self,issue):
        
        print("Select the book you want to issue\n")
        if  issue in  self.book :
           print(f"Okay u have been issued the {issue}  book. Please make sure u return in 15days with safe: \n ")
        #    print("if u by chance are late to return the book there is a fine of 10rs a day:\n")
           self.book.remove(issue)

        else:
            print("this book aleready been issued")


    def returnbook(self,issue):
        
        self.book.append(issue)
        print(f" thank u")
        
   
        # charge =0
      
        # # for issue in self.book:
        # if issue == "css" :
        #         self.book.append(issue)
        #         print(f"u returned the book on time , THANK YOU:\n")
                
               
        # elif issue!= "css" :
        #         print(f"hey student u need to return  book , it's already due \n")
        #         charge+=10
        #         print(f"u have been charged  a rupees of  {charge} \n")
                
        # else  :
        #         charge+=10
        #         print( f" hey student ur due date exceeded  and the charge is {charge}")
               



class student(library):
    
    def issuebook(self):
        self.book= input(f"enter the book name ")
        return self.book
    def returnbook(self):
        self.book= input(f"enter the book name ")
        return self.book
    


if __name__ == "__main__":
    l1=library(["css","html","python","c","c++"])
    # l1.issuebook("css")
    # l1.returnbook("css")
    # # l1.duedate()

    s1=student()
    while True :
        welcome = ''''' hi welcome to the library "
                    1 . See all books"
                    2 . issue a  book "
                    3 . return a book "
                    4 . exit the library '''''

        print(welcome)
        a = int(input("enter a choice from the above mentioned "))
        try :
    
            if a ==1:
                l1.availablebooks()
            elif a==2:
                l1.issuebook(s1.issuebook())
            elif a==3:
                l1.returnbook(s1.returnbook())

            elif a==4:
                exit()

        except Exception as e:

            print(f"u entered a wrong choice{e}")   

        
                        