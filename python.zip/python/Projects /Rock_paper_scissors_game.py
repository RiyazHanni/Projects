
import random
print("hello welcome \n")
print("R u ready ?: LET's GOOO")
def player():
    player=input(" your turn : choose rock or paper or scissor \n")
    if player in ["rock","ROCK","r","R"]:
        player='r'
        return player
    elif player in ["paper","PAPER","p","P"]:
        player='p'
        return player
    elif player in ["SCISSOR","scissor","s","S"]:
        player ='s'
        return player
    else:
        print("u had choosen the wrong one : re enter the proper")
        player()

def comp():
    comp=random.randint(1,3)
    
    if comp==1:
        comp = 'r'
        return comp 
       
    elif comp ==2:
            comp ='p'
            return comp
    elif comp==3:
            comp='s'
            return comp
        




def game():
    a=player()
    b=comp()
    print("the comp choice is   ",b) 

    if a == 'r':
        if b== 'r':
            print("tie")
            return print
        elif b=='p':
            print("comp win")
            return print
        elif b=='s':
            print("player win")
            return print

    if a == 'p':
        if b== 'r':
            print("player win")
            return print
        elif b=='p':
            print("tie")
            return print
        elif b=='s':
            print("comp win")
            return print

    if a == 's':
        if b== 'r':
            print("comp win")
            return print
        elif b=='p':
            print("player win")
            return print
        elif b=='s':
            print("tie")
            return print
    

# print( "the player choosed ",player())
# print("the comp choosed",comp())

c=game()
print(c )


    