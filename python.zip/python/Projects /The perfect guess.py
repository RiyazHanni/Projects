with open("sample.txt",'r') as f:
    highscore=f.read()
    print(f"LET'S GOO NOW IT IS THE TIME TO BREAK THE HIGHSCORE WHICH IS  {str(highscore)} TRY TO GUESS FASTER")




import random
randomnumber= random.randint(1,100)

count=0
userguess=False
while(userguess!=randomnumber):
    userguess=int(input("enter your guess btw 1 to 100 \n"))
    if(userguess==randomnumber):
        
        print("hurray!! You Gussed it correct\n")
        print("the no of times u took to guess the no is    ", +   count+1)
    else:
        if(userguess>randomnumber):
            print("Ewwww the guess is wrong & ur guess is larger ")
            print("Guess the samller no now!!")
        else:
            print("Ewwww the guess is wrong try again & ur guess is smaller")
            print("Guess the  larger no  now!!")
        count+=1




        
if(highscore<str(count+1)):  
    with open ("sample.txt",'w') as f:  
        print("SHESHHHH U HAVE BROKEN THE HIGH SCORE")
        b=f.write(str(count+1))
        print("AND THE NEW RECORD IS ", count+1)
else:
    print("OOPS u have taken more chance to guess ")